java -cp ./target/springboot-prototype-with-maven-0.0.1-SNAPSHOT.jar:target/dependency/* HiveDataProviderTest
